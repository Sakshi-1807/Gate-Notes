
## RIBHU GATE NOTES 

- [NOTES LINK](https://drive.google.com/drive/folders/1v1Vu91TQuzASmK7pQ_QrSOrpW4LC6w1V)
